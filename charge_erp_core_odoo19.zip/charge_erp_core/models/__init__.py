# -*- coding: utf-8 -*-

from . import student
from . import course
from . import faculty
from . import subject
from . import batch
from . import program_level
from . import program
from . import department
from . import academic_term
from . import academic_year
