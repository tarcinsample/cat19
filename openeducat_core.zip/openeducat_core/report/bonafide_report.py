from odoo import api, models


class BonafideCertificateReport(models.AbstractModel):
    _name = 'report.openeducat_core.report_student_bonafide'
    _description = 'Bonafide Certificate Report'

    @api.model
    def _get_report_values(self, docids, data=None):
        print(docids,'---------------------------docids')
        print(self,'---------------------------self')
        model = self.env.context.get('active_model')
        print(model,'-----------------------model')
        docs = self.env[model].browse(self.env.context.get('active_id'))
        for do in docs:
            print(do,'--------------------------do')
        
        # Automatically assign certificate numbers if not already set
        for student in docs:
            print(student,'-------------------------student')
            if not student.certificate_number:
                student.certificate_number = self.env['ir.sequence'].next_by_code('op.student.certificate')
        
        return {
            'doc_ids': docids,
            'doc_model': model,
            'docs': docs,
            'data': data or {},
        } 